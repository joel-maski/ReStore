import { Typography } from "@mui/material";

export default function HomePage() {
    return (
        <Typography variant="h2">
            Home page
        </Typography>
    )
}